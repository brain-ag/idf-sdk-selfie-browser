function iniciaSelfie() {
  let selfie = new window.BrScanSDKSelfie.Selfie(
    "sua-chave-aqui"
  );

  // Caso queira trocar a cor dos botões, cor de fundo das orientações e a fonte do componente, aqui está o exemplo:
  // document.documentElement.style.setProperty('--cor-primary', '#123');
  // document.documentElement.style.setProperty('--font-family', 'Inter');
  // document.documentElement.style.setProperty('--cor-background-orientacoes', 'red');

  // Imagens que são possíveis serem alteradas no componente:
  // selfie.imgLiberar = '';
  // selfie.imgLoading = '';
  // selfie.imgLoadingFotografar = '';
  // selfie.imgErrorDocumento = '';
  // selfie.imgTelaModal = '';
  // selfie.imgDicasRostoCentralizado = '';
  // selfie.imgDicasAmbienteIluminado = '';
  // selfie.imgDicasNaoAcessorios = '';
  // selfie.imgDicasSigaAsIntrucoes = '';
  // selfie.imgFecharIcone = '';
  // selfie.imgOkIcone = '';

  // Caso queira desativar a tela de instrução:
  // selfie.wizzard = false;

  // Efeito sonoro no fim da captura da selfie
  // selfie.playCaptureSound = true;
  
  // Inicia a Selfie com câmera traseira
  // selfie.cameraTraseira = true;
  selfie
    .iniciaSelfie(document.getElementById("selfie"))
    .then((selfie) => {
      console.log(selfie);
      alert("Selfie recebida com sucesso");
    })
    .catch((err) => {
      console.log("Error id: " + err.id + "\nError message: " + err.desc);
    });
}

document.addEventListener("DOMContentLoaded", function (event) {
  iniciaSelfie();
});
